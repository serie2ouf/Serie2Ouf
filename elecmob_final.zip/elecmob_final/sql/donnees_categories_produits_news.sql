-- Données de départ (alternative à "symfony console app:init-data").
-- Valable MySQL / MariaDB ET SQL Server. À lancer APRES doctrine:migrations:migrate,
-- sur des tables VIDES (les identifiants 1, 2, 3 des catégories sont utilisés par les produits).
-- Les utilisateurs ne sont PAS ici (mots de passe hachés) : utilise app:init-data ou /register.

INSERT INTO categorie (libelle) VALUES ('Hoverboards');
INSERT INTO categorie (libelle) VALUES ('Trottinettes');
INSERT INTO categorie (libelle) VALUES ('Vélos');

INSERT INTO produit (une_categorie_id, designation, detail, prix, photo) VALUES
(1, 'Hoverboard', 'Un hoverboard pour toutes les situations.', 210.00, 'H01.jpg'),
(1, 'Hoverboard et Hoverkart', 'Passe du mode glisse au mode kart en un instant !', 330.00, 'H02.jpg'),
(1, 'Hoverboard fun', 'L''équilibre parfait entre style, fun et liberté.', 230.00, 'H03.jpg'),
(2, 'Trottinette électrique Xénon-S', 'Compacte, légère et parfaite pour vos trajets quotidiens.', 625.00, 'T01.jpg'),
(2, 'Trottinette électrique Xénon-R', 'Puissance, autonomie et design pour une conduite sans limites.', 915.00, 'T02.jpg'),
(2, 'Trottinette électrique Helium', 'Vitesse, confort et technologie pour les plus exigeants.', 1249.00, 'T03.jpg'),
(3, 'Vélo électrique', 'Le compagnon idéal pour une mobilité douce et efficace.', 990.00, 'V01.jpg'),
(3, 'Vélo électrique tout terrain', 'Conçu pour l''aventure, prêt pour tous les terrains.', 1240.00, 'V02.jpg'),
(3, 'Vélo électrique pliable', 'Pratique, rapide et facile à ranger : la liberté urbaine.', 825.00, 'V03.jpg');

INSERT INTO news (titre, datenews, contenu, image) VALUES ('Tous en vélo !', '2026-08-18', 'Découvrez nos vélos électriques haute performance', 'Pub_1-1200x467.webp');
INSERT INTO news (titre, datenews, contenu, image) VALUES ('La Trottinette sans effort !', '2026-11-18', 'Mobilité urbaine rapide et écologique', 'Pub_2-1200x467.webp');
INSERT INTO news (titre, datenews, contenu, image) VALUES ('Hoverboard ... toujours plus fun !', '2026-01-09', 'L''expérience de mobilité la plus innovante', 'Pub_3-1200x467.webp');
INSERT INTO news (titre, datenews, contenu, image) VALUES ('Tous à scooters !', '2026-01-14', 'Se déplacer plus loin sans bruit !', 'Pub_4-1200x467.webp');
