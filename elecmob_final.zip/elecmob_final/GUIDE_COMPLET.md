# Electric Mobility – Guide complet (Symfony 8)

> Rien n'a pu être exécuté ni vérifié syntaxiquement de mon côté (pas de PHP). Après la copie, lance
> `symfony console doctrine:schema:validate` et `symfony console debug:router` pour détecter toute erreur.

## ÉTAPE 1 – Créer le projet
```
symfony new electricmobility --webapp
cd electricmobility
composer require symfony/google-mailer symfony/messenger
```

## ÉTAPE 2 – Base de données DE ZÉRO
### Option A : WAMP (MySQL/MariaDB)
1. Démarre WAMP (icône verte), ouvre phpMyAdmin (http://localhost/phpmyadmin, root, mot de passe vide).
2. Ne crée AUCUNE table à la main : Doctrine les crée.
3. Copie `.env.local.example` en `.env.local` et garde la ligne MySQL :
   `DATABASE_URL="mysql://root:@127.0.0.1:3306/electricmobility?serverVersion=8.0&charset=utf8mb4"`
   (avec MariaDB mets `serverVersion=10.11.2-MariaDB`).
4. Crée la base : `symfony console doctrine:database:create`

### Option B : SQL Server (lycée)
1. Dans SSMS, crée une base vide `electricmobility` (ou laisse Doctrine la créer).
2. Dans `.env.local`, utilise la ligne SQL Server de `.env.local.example`
   (ODBC 17, `Encrypt=no` / `TrustServerCertificate=yes` si besoin).
3. `symfony console doctrine:database:create`

## ÉTAPE 3 – Copier les fichiers
Copie le contenu de ce dossier (src, templates, config, public, sql) dans ton projet en écrasant.
Supprime l'ancien `src/Entity/User.php`, `LigneDeCommande.php` et leurs repositories/formulaires
si présents. `config/packages/security.yaml` : celui fourni remplace le tien.

## ÉTAPE 4 – Créer les tables
Si tu as DÉJÀ une base avec les anciennes tables (`user`, `ligne_de_commande`) :
le plus simple en TP est de tout supprimer :
```
symfony console doctrine:schema:drop --force --full-database
```
puis (dans tous les cas) :
```
symfony console doctrine:migrations:diff
symfony console doctrine:migrations:migrate
symfony console doctrine:schema:validate
```
(Supprime d'abord les anciens fichiers de `migrations/` s'ils sont obsolètes.)
Tables obtenues : `news`, `categorie`, `produit`, `utilisateur`, `commande`,
`ligne_commande_produit`, `contact`, `messenger_messages`.

## ÉTAPE 5 – Remplir la base
```
symfony console app:init-data
```
Crée : 3 catégories, 9 produits, 4 news et 2 comptes
- admin : `jean.dumont@gmail.com` / `Admin2026!`
- utilisateur : `pierre.dupond@gmail.com` / `Util2026!!`

(Alternative : `sql/donnees_categories_produits_news.sql` pour catégories/produits/news seulement.)

## ÉTAPE 6 – Images
Crée (déjà présents, vides) `public/images/divers`, `produits`, `profils` et place les images du prof :
- divers : `Pub_1-1200x467.webp` … `Pub_4-1200x467.webp`, `Logo*.png`, `accueil.png`,
  `MenuConnexionOK.png`, `MenuConnexionKO.png`, `AvatarInconnu.png`, `INDISPONIBLE.jpg`
- produits : `H01.jpg H02.jpg H03.jpg T01.jpg T02.jpg T03.jpg V01.jpg V02.jpg V03.jpg`
- profils : vide (reçoit les photos envoyées par les utilisateurs)

## ÉTAPE 7 – Mail (formulaire de contact)
Dans `.env.local` : `MAILER_DSN=gmail://adresse:MOT_DE_PASSE_APPLICATION@default`
(mot de passe d'application Google, pas ton mot de passe normal). Sans cela, le message est quand
même enregistré en base, seul l'envoi échoue (erreur gérée).

## ÉTAPE 8 – Lancer et tester
```
symfony serve
```
- `/` accueil, `/produit/` catalogue, `/produit/categ/1`
- connexion admin → menu Gestion (produits, catégories, utilisateurs, news)
- connexion user → ajouter au panier → Payer → `/commande/`
- `/contact`, `/profil` (photo, mot de passe), `/register`

## En cas de problème
- `Table 'xxx' doesn't exist` → refais l'étape 4.
- `Unknown column` → `doctrine:schema:update --dump-sql` pour voir la différence.
- Accents illisibles sous SQL Server → vérifie le charset UTF-8 dans l'URL.
- 403 sur une page admin → le compte n'a pas ROLE_ADMIN.
