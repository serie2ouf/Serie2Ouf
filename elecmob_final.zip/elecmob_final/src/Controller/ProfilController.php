<?php

namespace App\Controller;

use App\Entity\Utilisateur;
use App\Form\ChangePasswordType;
use App\Form\ProfilPhotoType;
use App\Form\ProfilType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Component\String\Slugger\SluggerInterface;

#[Route('/profil')]
#[IsGranted('IS_AUTHENTICATED_FULLY')]
final class ProfilController extends AbstractController
{
    #[Route(name: 'app_profil_index', methods: ['GET'])]
    public function index(): Response
    {
        return $this->render('profil/index.html.twig', [
            'utilisateur' => $this->getUser(),
        ]);
    }

    #[Route('/edit', name: 'app_profil_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, EntityManagerInterface $entityManager): Response
    {
        /** @var Utilisateur $user */
        $user = $this->getUser();
        $form = $this->createForm(ProfilType::class, $user);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();
            $this->addFlash('success', 'Vos informations ont été modifiées');
            return $this->redirectToRoute('app_profil_index');
        }

        return $this->render('profil/form.html.twig', [
            'titre' => 'Modifier mes informations',
            'form' => $form,
        ]);
    }

    #[Route('/photo', name: 'app_profil_photo', methods: ['GET', 'POST'])]
    public function photo(Request $request, EntityManagerInterface $entityManager, SluggerInterface $slugger): Response
    {
        /** @var Utilisateur $user */
        $user = $this->getUser();
        $form = $this->createForm(ProfilPhotoType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $fichier = $form->get('photo')->getData();
            $dossier = $this->getParameter('kernel.project_dir') . '/public/images/profils';

            $nomSecurise = $slugger->slug(pathinfo($fichier->getClientOriginalName(), PATHINFO_FILENAME));
            $nouveauNom = $nomSecurise . '-' . uniqid() . '.' . $fichier->guessExtension();
            $fichier->move($dossier, $nouveauNom);

            // Supprime l'ancienne photo si elle existe
            if ($user->getPhoto() && is_file($dossier . '/' . $user->getPhoto())) {
                unlink($dossier . '/' . $user->getPhoto());
            }

            $user->setPhoto($nouveauNom);
            $entityManager->flush();

            $this->addFlash('success', 'Votre photo a été modifiée');
            return $this->redirectToRoute('app_profil_index');
        }

        return $this->render('profil/form.html.twig', [
            'titre' => 'Modifier ma photo',
            'form' => $form,
        ]);
    }

    #[Route('/password', name: 'app_profil_password', methods: ['GET', 'POST'])]
    public function password(Request $request, EntityManagerInterface $entityManager, UserPasswordHasherInterface $hasher): Response
    {
        /** @var Utilisateur $user */
        $user = $this->getUser();
        $form = $this->createForm(ChangePasswordType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $nouveau = $form->get('newPassword')->getData();
            $user->setPassword($hasher->hashPassword($user, $nouveau));
            $entityManager->flush();

            // Le hash du mot de passe change : Symfony déconnecte l'utilisateur, c'est normal.
            $this->addFlash('success', 'Mot de passe modifié, veuillez vous reconnecter');
            return $this->redirectToRoute('app_login');
        }

        return $this->render('profil/form.html.twig', [
            'titre' => 'Modifier mon mot de passe',
            'form' => $form,
        ]);
    }
}
