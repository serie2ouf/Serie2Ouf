<?php

namespace App\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints\Image;
use Symfony\Component\Validator\Constraints\NotBlank;

class ProfilPhotoType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->add('photo', FileType::class, [
            'label' => 'Choisissez une image (JPG, PNG, WEBP - 2 Mo max)',
            'mapped' => false,
            'required' => true,
            'attr' => ['class' => 'form-control', 'accept' => 'image/*'],
            'constraints' => [
                new NotBlank(message: 'Veuillez choisir une image'),
                new Image(
                    maxSize: '2M',
                    mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
                    mimeTypesMessage: 'Format accepté : JPG, PNG ou WEBP',
                    maxSizeMessage: 'Image trop lourde (2 Mo maximum)',
                ),
            ],
        ]);
    }
}
